// used in launch.json to refer to an installed cds via an absolute path

const cds = require('@sap/cds');
cds.exec();
